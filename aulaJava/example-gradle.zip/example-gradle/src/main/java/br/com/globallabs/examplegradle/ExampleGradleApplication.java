package br.com.globallabs.examplegradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleGradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleGradleApplication.class, args);
	}

}
