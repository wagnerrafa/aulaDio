package br.com.globallabs.examplegradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleGradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
